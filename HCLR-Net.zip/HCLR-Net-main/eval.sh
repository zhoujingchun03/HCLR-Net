python val.py --weights $1 --project ./testimg/ --data ../../datasets/UIEB_end --device $2 
